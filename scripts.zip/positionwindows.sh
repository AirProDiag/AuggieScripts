#!/bin/bash
winmain=`xdotool search --name "^AirPro Auggie$"`
wintarget=`xdotool search --name "^AirPro Auggie Target$"`
xdotool windowsize $winmain 1024 600
xdotool windowmove $winmain 0 0 
xdotool windowsize $wintarget 1920 1080
xdotool windowmove $wintarget 1024 0 
exit 0
