#!/bin/bash
shutdown -P --no-wall 0
exit 0
