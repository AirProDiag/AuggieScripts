#!/bin/bash
xrandr --output $AUGGIE_TARGET_SCREEN_OUTPUT --brightness $1