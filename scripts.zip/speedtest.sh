#!/bin/bash
speedtest --simple --secure
exit 0
