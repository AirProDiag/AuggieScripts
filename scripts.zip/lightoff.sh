#!/bin/bash
stty -F /dev/ttyLIGHTS 9600 cs8 -cstopb -parenb
echo -en "\xa0\x01\x00\xa1" > /dev/ttyLIGHTS
exit 0
