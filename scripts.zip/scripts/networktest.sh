#!/bin/bash

# Usage: ./test.sh [{QAT|UAT|PRD}]
#  Defaults to QAT when no argument given.

env=$1
env="${env^^}"
if [[ ! "$env" =~ ^(QAT|UAT|PRD|)$ ]]; then
    echo "Usage: $0 [{QAT|UAT|PRD}]"
    exit -1
fi

dashenv=""
if [[ "$env" == "" ]];
then
    env="QAT"
fi

if [[ "$env" == "PRD" ]]
then
    dashenv=""
else
    dashenv="-$env"
fi

while true  # waits until auggie exits
do
    printf "\nPing SignalR ($env)      - "
    curl -s -o /dev/null -w "%{http_code} (%{time_total} s)" "https://api$dashenv.auggie.tech/signalr/ping"
    printf "\nPing Device API ($env)   - "
    curl -s -o /dev/null -w "%{http_code} (%{time_total} s)" "https://api$dashenv.auggie.tech/device/ping"
    printf "\nPing Device Web ($env)   - "
    curl -s -o /dev/null -w "%{http_code} (%{time_total} s)" --head "https://device$dashenv.auggie.tech"
    printf "\nPing Identity Web ($env) - "
    curl -s -o /dev/null -w "%{http_code} (%{time_total} s)" --head "https://auth$dashenv.airprodiag.com/ping"
    printf "\n"
done

