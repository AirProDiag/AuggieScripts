#!/bin/bash
# zip without directory path (-j)
zip -j $1/logs.zip $1/*
# upload zip file ($1=folder $2=url $3=device name $4,$5 deviceserial/bearer headers
curl -F file="@$1/logs.zip" -H "$4" -H "$5" "$2?devicename=$3"
# remove all files from logs folder
rm $1/*.*
