# Project Scripts Documentation

This repository contains a collection of scripts used by the Auggie Software. Below is a brief description of each script and how to use:

### `downloadcleanup.sh`
- **Purpose**: Cleans up `/auggie_*.deb`, `/wget-log` & `/wget_log.*` files in a specified path passed as a paramater.
- **Usage**: `./downloadcleanup.sh [PATH TO CLEANUP]`.

### `hidecamerawindow.sh`
- **Purpose**: Hides the `AirPro Auggie Camera` Window on Side Screen.
- **Usage**: Run to hide `AirPro Auggie Camera` window.

### `install.sh`
- **Purpose**: General installation script for setting up software. Accepts a package name as a paramter.
- **Usage**: Run as `./install.sh [PACKAGE NAME]`.

### `ipaddress.sh`
- **Purpose**: Displays the current IP address of the system.
- **Usage**: Simply execute to view IP address.

### `lightoff.sh`
- **Purpose**: Turns off Auggie LED lights by disabling the USB Relay.
- **Usage**: Run to deactivate lights.

### `lighton.sh`
- **Purpose**: Turns on Auggie LED lights by enabling the USB Relay.
- **Usage**: Execute to activate lights.

### `networktest.sh`
- **Purpose**: Performs a network test, checking connectivity and speed. Accepts an Orion Envrionment (PRD/UAT/QAT) as a param. Defaults to QAT by default.
- **Usage**: Run as `./networktest.sh [ORION ENVIRONMENT]`.

### `positionwindows.sh`
- **Purpose**: Positions the Auggie Main & Target windows on the appropriate displays.
- **Usage**: Execute to reposition windows.

### `restart.sh`
- **Purpose**: Restarts a specified service or the entire system.
- **Usage**: Run to reboot.

### `showcamerawindow.sh`
- **Purpose**: Shows the `AirPro Auggie Camera` Window on Side Screen.
- **Usage**: Execute to show the camera window.

### `shutdown.sh`
- **Purpose**: Shuts down the system safely.
- **Usage**: Run to initiate shutdown.

### `speedtest.sh`
- **Purpose**: Conducts an internet speed test.
- **Usage**: Execute to check internet speed.

### `startdownload.sh`
- **Purpose**: Initiates a wget process. Accepts 5 Parameters: $1: File Name, $2: Log File Name, $3: The first HTTP header to include in the request, $4: The second HTTP header to include in the request, $5: The URL to download.
- **Usage**: Run as `./startdownload.sh [FILE NAME] [LOG NAME] [HEADER1] [HEADER2] [URL]`.

### `systeminfo.sh`
- **Purpose**: Displays the MAC Address for wlo1 or wlo2, depending on which is present.
- **Usage**: Execute to view current wifi MAC address of wlo1 or wlo2 depending which is connected.

### `targetbrightness.sh`
- **Purpose**: Adjusts the screen brightness to a specified target param from 0 to 1.
- **Usage**: Run as `./targetbrightness.sh [eg. 0.3 for 30%]`.

### `teamvieweroff.sh`
- **Purpose**: Disables the TeamViewer Host daemon.
- **Usage**: Execute to turn off the service.

### `teamvieweron.sh`
- **Purpose**: Enables the TeamViewer Host daemon.
- **Usage**: Run to start the service.

### `uploadlog.sh`
- **Purpose**: Uploads logs to Orion. Accepts the following: $1: folder, $2: url, $3: device name, $4: Headers, $5: deviceserial.
- **Usage**: Run as `./uploadlog.sh [FOLDER] [URL] [NAME] [HEADER] [SERIAL]`.
